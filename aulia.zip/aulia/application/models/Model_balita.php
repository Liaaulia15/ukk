<?php
class Model_balita extends CI_model 
{
    public function getAllbalita()
    {
        return $query = $this->db->get('balita')->result_array();
    }

    public function Tambahbalita()
    {
        $data = [
            "balita" => $this->input->post('balita', true)
        ];

        $this->db->insert('balita', $data);
    }

    public function Ubahbalita()
    {
        $data = [
            "balita" => $this->input->post('balita', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('balita', $data);
    }

    public function hapusbalita($id)       
    {
        $this->db->delete('balita');
    }

    public function getbalitaById($id)
    {
        return $this->db->get_where('balita', ['id' => $id])->row_array();
    }

    public function Caribalita()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('balita', $keyword);
        return $this->db->get('balita')->result_array();
    }
}

?>