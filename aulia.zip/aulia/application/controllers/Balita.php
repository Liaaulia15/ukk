<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Balita extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_balita');
        $this->load->model('Model_balita');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'balita';
        if ($this->input->post('submit')) {
            $data['keyword'] = $this->input->post('keyword');
        } else {
            $data['keyword'] = null;
        }
        
        $data['balita'] = $this->Model_balita->getAllbalita($data['keyword']);
        $this->load->view('templates/header.php', $data);
        $this->load->view('balita/index.php', $data);
        $this->load->view('templates/footer.php');
    }
    
    public function tambah()
    {
        $data['balita'] = $this->Model_balita->getAllbalita();
        $this->form_validation->set_rules('nama', 'nama', 'trim|required|numeric');
        $this->form_validation->set_rules('tgl_lahir', 'tgl_lahir', 'trim|required');
        $this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'trim|required|');
        $this->form_validation->set_rules('umur', 'umur', 'trim|required');
        


        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah balita';

            $this->load->view('templates/header.php', $data);
            $this->load->view('balita/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_balita->Tambahbalita();
            redirect('balita');
        }
        
    }

    public function ubah($id)
    {
        $data['balita'] = $this->Model_balita->getbalitaById($id);
        $this->form_validation->set_rules('nama', 'nama', 'trim|required|numeric');
        $this->form_validation->set_rules('tgl_lahir', 'tgl_lahir', 'trim|required');
        $this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'trim|required|');
        $this->form_validation->set_rules('umur', 'umur', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah balita';

            $this->load->view('templates/header.php', $data);
            $this->load->view('balita/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_balita->Ubahbalita();
            $this->session->set_flashdata('flash', 'Diubahkan');
            redirect('balita');
        }
        
    }

    public function detail($id)
    {
        $data['balita'] = $this->Model_balita->getbalitaById($id);
        $data['title'] = 'Detail balita';
        $this->load->view('templates/header.php', $data);
        $this->load->view('balita/detail.php', $data);
        $this->load->view('templates/footer.php');

    }

    public function hapus($id)
    {
        $data['balita'] = $this->Model_balita->getbalitaById($id);
        $this->Model_balita->hapusbalita($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('balita');
    }
}


































































































