<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class kader extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_kader');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'data kader';

        $data['kader'] = $this->Model_kader->getAllkader();
        if( $this->input->post('keyword') ) {
            $data['kader'] = $this->Model_kader->Carikader();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('kader/index.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('nama', 'nama', 'trim|required');
        $this->form_validation->set_rules('jabatan', 'jabatan', 'trim|required');
        $this->form_validation->set_rules('tgl_lahir', 'tgl_lahir', 'trim|required');
        $this->form_validation->set_rules('alamat', 'alamat', 'trim|required');
        $this->form_validation->set_rules('no_hp', 'no_hp', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah kader';

            $this->load->view('templates/header.php', $data);
            $this->load->view('kader/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_kader->Tambahkader();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('kader');
        }
        
    }

    public function ubah($id)
    {
        $this->form_validation->set_rules('nama', 'nama', 'trim|required');
        $this->form_validation->set_rules('jabatan', 'jabatan', 'trim|required');
        $this->form_validation->set_rules('tgl_lahir', 'tgl_lahir', 'trim|required');
        $this->form_validation->set_rules('alamat', 'alamat', 'trim|required');
        $this->form_validation->set_rules('no_hp', 'no_hp', 'trim|required');

        $data['kader'] = $this->Model_kader->getkaderById($id);

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah kader';

            $this->load->view('templates/header.php', $data);
            $this->load->view('kader/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_kader->Ubahkader();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('kader');
        }
    } 
     public function hapus($id)
        {
            $this->Model_kader->hapuskader($id);
            $this->session->set_flashdata('flash', 'Dihapus');
            redirect('kader');
        }
    }
