<div class="container">
    <?= form_open_multipart('balita/tambah');?>
        <legend>Ubah Data Balita</legend>
        <div class="mb-3">
            <label for="nama" class="form-label">nama</label>
            <input type="text" class="form-control" id="nama" name="nama" style="width : 500px;" value="<?= $balita['nama']; ?>">
            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
        </div>
        <div class="mb-3">
            <label for=" tanggal lahir" class="form-label"> tanggal lahir</label>
            <input type="date" class="form-control" id=" tanggal lahir" name=" tanggal lahir" style="width : 500px;" value="<?= $balita[' tanggal lahir']; ?>">
            <div class="form-text text-danger"><?= form_error(' tanggal lahir'); ?></div>
        </div> 
        <div class="mb-3">
             <label for="jenis kelamin" class="form-label">jenis kelamin</label>
            <input type="text" class="form-control" id="jenis kelamin" name="jenis kelamin" style="width : 500px;" value="<?= $balita['jenis kelamin']; ?>">
            <div class="form-text text-danger"><?= form_error('jenis kelamin'); ?></div>
        </div>
        <div class="mb-3">
            <label for="umur" class="form-label">umur</label>
            <input type="text" class="form-control" id="umur" name="umur" style="width : 500px;" value="<?= $balita['umur']; ?>">
            <div class="form-text text-danger"><?= form_error('umur'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="nama ibu" class="form-label">nama ibu</label>
            <input type="text" class="form-control" id="nama ibu" name="nama ibu" style="width : 500px;" value="<?= $balita['nama ibu']; ?>">
            <div class="form-text text-danger"><?= form_error('nama ibu'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="nama ayah" class="form-label">nama ayah</label>
            <input type="text" class="form-control" id="nama ayah" name="nama ayah" style="width : 500px;" value="<?= $balita['nama ayah']; ?>">
            <div class="form-text text-danger"><?= form_error('nama ayah'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="alamat" class="form-label">alamat</label>
            <input type="text" class="form-control" id="alamat" name="alamat" style="width : 500px;" value="<?= $balita['alamat']; ?>">
            <div class="form-text text-danger"><?= form_error('alamat'); ?></div>
        </div> 
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>








































