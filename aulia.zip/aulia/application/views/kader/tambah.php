<div class="container">
    <?= form_open_multipart('kader/tambah');?>
        <legend>Tambah Data kader</legend>
        <div class="mb-3">
            <label for="nama" class="form-label">nama</label>
            <input type="text" class="form-control" id="nama" name="nama" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
        </div>
        <div class="mb-3">
            <label for="jabatan" class="form-label">jabatan</label>
            <input type="text" class="form-control" id="jabatan" name="jabatan" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('jabatan'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="tgl lahir" class="form-label">tgl lahir</label>
            <input type="date" class="form-control" id="tgl lahir" name="tgl lahir" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('tgl lahir'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="alamat" class="form-label">alamat</label>
            <input type="text" class="form-control" id="alamat" name="alamat" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('alamat'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="no_hp" class="form-label">No HP</label>
            <input type="text" class="form-control" id="no_hp" name="no_hp" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('no_hp'); ?></div>
        </div> 
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>






